//Actions
$(".user-edit").click(function () {
    let id = $(this).parent().attr('id');
    window.location =  window.location + '/' + id + '/edit';
});

$(".user-delete").click(function () {
    let id = $(this).parent().attr('id');
    if (confirm("Da li ste sigurni da želite da uklonite korisnika?")) {
        window.location =  window.location + '/' + id + '/remove'
    }
    return false;
});