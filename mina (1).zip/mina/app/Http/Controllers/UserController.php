<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:web');
    }

    public function users()
    {
        $users = (new User)->all();

        return view('user.users', ['users' => $users]);
    }

    public function create()
    {

        return view('user.user-create');
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|string|unique:users',
            'password' => 'required|confirmed|string|min:6'
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withInput();
        }


        $user = (new User)->create($request->all());
        $user->first_name = ucfirst(request('first_name'));
        $user->last_name = ucfirst(request('last_name'));
        $user->password = bcrypt(request('password'));
        $user->save();
        return redirect('/users');

    }

    public function edit($id)
    {
        $user = (new User)->find($id);

        return view('user.user-edit', ['user' => $user]);
    }

    public function update(Request $request, $id)
    {
        $user = (new User)->find($id);

        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|string|unique:users,email,' . $user->id,
        ]);

        if ($validator->fails()) {

            return redirect()->back()->withInput();
        }

        $user->update($request->all());
        $user->first_name = ucfirst(request('first_name'));
        $user->last_name = ucfirst(request('last_name'));
        $user->save();

        return redirect('/users');

    }

    public function remove($id)
    {
        try {
            $user = (new User)->find($id);
            $user->delete();

            return redirect('/users');
        } catch (\Exception $exception) {

            return redirect('/users');
        }
    }
}
