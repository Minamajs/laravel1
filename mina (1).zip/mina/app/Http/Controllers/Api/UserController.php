<?php

namespace App\Http\Controllers\Api;

use App\Animal;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255'
        ]);

        if ($validator->fails()) {
            $message = "Pogrešan unos";

            return response()->json(compact('message'), 400);
        }

        $user = (new User)->find($request->id);
        $user->update($request->all());
        $user->first_name = ucfirst(request('first_name'));
        $user->last_name = ucfirst(request('last_name'));
        $user->save();

        $message = "Uspešno ste izmenili informacije o korisniku.";

        return response()->json(compact('user', 'message'), 200);
    }

    public function remove(Request $request)
    {
        $user = (new User)->find($request->id);
        try {
            $user->delete();
            $message = 'Uspešno brisanje korisnika';
            return response()->json(compact('user', 'message'), 200);
        } catch (\Exception $e) {
            $message = 'Neuspešan pokušaj brisanja korisnika';
            return response()->json(compact('user', 'message'), 400);
        }

    }

    public function myAnimals(Request $request)
    {

        $animals = (new Animal)->with('type')->where('user_id', $request->id)->get();

        return response()->json(compact('animals'), 200);
    }
}
