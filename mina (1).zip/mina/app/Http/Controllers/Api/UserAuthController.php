<?php

namespace App\Http\Controllers\Api;

use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

class UserAuthController extends Controller
{
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|string|unique:users',
            'password' => 'required|confirmed|string|min:6'
        ]);

        if ($validator->fails()) {
            $error = $validator->errors();
            $message = "Pogrešan unos";
            return response()->json(compact('message', 'error'), 400);
        }

        $user = (new User)->create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'password' => bcrypt($request->password)
        ]);


        $token = auth('api')->login($user);

        return $this->respondWithToken($token);
    }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (!$token = auth('api')->attempt($credentials)) {
            $message = 'Pogrešan unos';
            return response()->json(compact('message'), 400);
        }

        $user = auth('api')->user();

        $message = 'Uspešno logovanje na sistem!';

        return response()->json(compact('token', 'user', 'message'), 200);
    }

    public function logout()
    {
        auth()->logout();
        $message = "Uspešno ste se odjavili sa sistema!";
        return response()->json(compact('message'), 200);
    }

    public function respondWithToken($token)
    {
        $message = "Success";
        $access_token = $token;
        $token_type = 'bearer';
        $user = auth('api')->user();

        return response()->json(compact('message', 'token', 'token_type', 'user'), 200);

    }
}
