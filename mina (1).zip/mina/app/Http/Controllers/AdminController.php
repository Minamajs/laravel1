<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function __construct() {
        $this->middleware('guest:web', ['except'=>['logout']]);
    }

    public function showLoginForm() {
        return view('auth.login');
    }

    public function login(Request $request) {
        $this->validate($request, [
            'email' =>'required|string|email',
            'password' => 'required|min:6'
        ]);

        if (Auth::guard('web')->attempt(['email'=>$request->email, 'password'=>$request->password], $request->remember)){
            return redirect()->intended(route('dashboard'));
        }

        return redirect()->back()->withInput($request->only('email', 'remember'));
    }

    public function logout(){
        Auth::guard('web')->logout();
        return redirect('/login');
    }
}
