<?php

namespace App\Http\Controllers;

use App\Animal;
use App\AnimalType;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AnimalController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:web');
    }

    public function animals()
    {
        $animals = (new Animal)->all();

        return view('animal.animals', ['animals' => $animals]);
    }

    public function create()
    {

        $type = (new AnimalType)->all();
        $user = (new User)->all();

        return view('animal.animal-create', ['user' => $user, 'type' => $type]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255'
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withInput();
        }


        $animal = (new Animal)->create($request->all());
        $animal->name = ucfirst(request('name'));
        $animal->save();
        return redirect('/animals');

    }

    public function edit($id)
    {
        $animal = (new Animal)->find($id);
        $type = (new AnimalType)->where('id', '!=', $animal->animal_type)->get();
        $user = (new User)->where('id', '!=', $animal->user_id)->get();

        return view('animal.animal-edit', ['user' => $user, 'type' => $type, 'animal' => $animal]);
    }

    public function update(Request $request, $id)
    {
        $animal = (new Animal)->find($id);

        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255'
        ]);

        if ($validator->fails()) {

            return redirect()->back()->withInput();
        }

        $animal->update($request->all());
        $animal->first_name = ucfirst(request('name'));
        $animal->save();

        return redirect('/animals');

    }

    public function remove($id)
    {
        try {
            $user = (new Animal)->find($id);
            $user->delete();

            return redirect('/animals');
        } catch (\Exception $exception) {

            return redirect('/animals');
        }
    }
}
