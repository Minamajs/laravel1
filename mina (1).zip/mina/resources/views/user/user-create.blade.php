@extends('layouts.app')

@section('content')

    <div class="block block-content block-content-full container-fluid">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">

                    <!-- Page Content -->
                    <div class="content">

                        <form action="{{route('user.store')}}" method="POST"
                              class="form-horizontal form-bordered form-validate"
                              enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <div class="row justify-content-center">

                                <div class="col-md-6">


                                    <div class="container">
                                        <!--First Name-->
                                        <div class="row form-group{{ $errors->has('first_name') ? ' has-error' : '' }} form-inline">
                                            <div class="col-md-3">
                                                <label for="first_name" class="inline-label">Ime:</label>

                                                @if ($errors->has('first_name'))
                                                    <span class="help-block">
                                            <strong>{{ $errors->first('first_name') }}</strong>
                                        </span>
                                                @endif
                                            </div>
                                            <div class="col-md-6">
                                                <input id="first_name" type="text" class="form-control" name="first_name"
                                                       value="">
                                            </div>
                                        </div>
                                        <!--Last Name-->
                                        <div class="row form-group{{ $errors->has('last_name') ? ' has-error' : '' }} form-inline">
                                            <div class="col-md-3">
                                                <label for="last_name" class="inline-label">Prezime:</label>

                                                @if ($errors->has('last_name'))
                                                    <span class="help-block">
                                            <strong>{{ $errors->first('last_name') }}</strong>
                                        </span>
                                                @endif
                                            </div>
                                            <div class="col-md-6">
                                                <input id="last_name" type="text" class="form-control" name="last_name"
                                                       value="" required autofocus>
                                            </div>
                                        </div>

                                        <!--Email-->
                                        <div class="row form-group{{ $errors->has('email') ? ' has-error' : '' }} form-inline">
                                            <div class="col-md-3">
                                                <label for="email" class="inline-label">E-pošta</label>

                                                @if ($errors->has('email'))
                                                    <span class="help-block">
                                            <strong>{{ $errors->first('email') }}</strong>
                                        </span>
                                                @endif
                                            </div>
                                            <div class="col-md-6">
                                                <input id="email" type="email" class="form-control" name="email"
                                                       value="" required autofocus>
                                            </div>
                                        </div>

                                        <!--Password-->
                                        <div class="row form-group{{ $errors->has('password') ? ' has-error' : '' }} form-inline">
                                            <div class="col-md-3">
                                                <label for="username" class="inline-label">Lozinka:</label>

                                                @if ($errors->has('password'))
                                                    <span class="help-block">
                                            <strong>{{ $errors->first('password') }}</strong>
                                        </span>
                                                @endif
                                            </div>
                                            <div class="col-md-6">
                                                <input id="password" type="password" class="form-control" name="password" value="" required autofocus>
                                            </div>
                                        </div>
                                        <div class="row form-group form-inline">
                                            <div class="col-md-3">
                                                <label for="password-confirm" class="inline-label">Potvrda Lozinke:</label>
                                            </div>

                                            <div class="col-md-6">
                                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-md-12 col-md-offset-4">
                                            <button type="submit" class="btn btn-primary btn-confirm">
                                                Kreiranje korisnika
                                            </button>
                                        </div>
                                    </div>
                                </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js_after')

    @include('user.scripts')

@endsection
