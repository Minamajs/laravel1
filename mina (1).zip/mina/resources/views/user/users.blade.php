@extends('layouts.app')

@section('content')

    <div class="block block-content block-content-full container-fluid">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">

                    <!-- Page Content -->
                    <div class="content">
                        <!-- Dynamic Table Full -->


                        <table class="table table-bordered table-hover" id="ourDatatable">
                            <thead>
                            <tr>
                                <th>Ime</th>
                                <th>Prezime</th>
                                <th>Email</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($users as $user)
                                <tr>
                                    <td>{{$user->first_name}}</td>
                                    <td>{{$user->last_name}}</td>
                                    <td>{{$user->email}}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                        <!-- END Dynamic Table Full -->
                        <div class="pb-3 text-right">
                            <button class=' btn btn-primary btn-md create-user' data-toggle='tooltip'
                                    data-placement='top' title='Novi korisnik'>
                                <a style="color: white" href="{{url('/users/create')}}">Kreiranje novog korisnika</a>
                            </button>

                            <button class=' btn btn-primary btn-md create-user' data-toggle='tooltip'
                                    data-placement='top' title='Novi korisnik'>
                                <a style="color: white" href="{{url('/')}}">Kontrolna tabla</a>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js_after')

    @include('user.scripts')

@endsection
