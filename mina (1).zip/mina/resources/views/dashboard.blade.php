@extends('layouts.app')

@section('content')

    <div class="block block-content block-content-full container-fluid">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Kontrolna tabla</div>

                    <!-- Page Content -->
                    <div class="content">
                        <div class="pb-3 text-right">
                            <button class=' btn btn-primary btn-md create-user' data-toggle='tooltip'
                                    data-placement='top' title='Novi korisnik'>
                                <a style="color: white" href="{{url('/users')}}">Korisnici</a>
                            </button>
                        </div>

                        <div class="pb-3 text-right">
                            <button class=' btn btn-primary btn-md create-user' data-toggle='tooltip'
                                    data-placement='top' title='Novi korisnik'>
                                <a style="color: white" href="{{url('/animals')}}">Životinje</a>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js_after')

    @include('user.scripts')

@endsection
