@extends('layouts.app')

@section('content')

    <div class="block block-content block-content-full container-fluid">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">

                    <!-- Page Content -->
                    <div class="content">

                        <form action="{{route('animal.store')}}" method="POST"
                              class="form-horizontal form-bordered form-validate"
                              enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <div class="row justify-content-center">

                                <div class="col-md-6">


                                    <div class="container">
                                        <!--Name-->
                                        <div class="row form-group{{ $errors->has('name') ? ' has-error' : '' }} form-inline">
                                            <div class="col-md-3">
                                                <label for="name" class="inline-label">Ime:</label>

                                                @if ($errors->has('name'))
                                                    <span class="help-block">
                                            <strong>{{ $errors->first('name') }}</strong>
                                        </span>
                                                @endif
                                            </div>
                                            <div class="col-md-6">
                                                <input id="name" type="text" class="form-control" name="name"
                                                       value="">
                                            </div>
                                        </div>
                                        <!--Age-->
                                        <div class="row form-group{{ $errors->has('age') ? ' has-error' : '' }} form-inline">
                                            <div class="col-md-3">
                                                <label for="age" class="inline-label">Starost:</label>

                                                @if ($errors->has('age'))
                                                    <span class="help-block">
                                            <strong>{{ $errors->first('age') }}</strong>
                                        </span>
                                                @endif
                                            </div>
                                            <div class="col-md-6">
                                                <input id="age" type="number" class="form-control" name="age"
                                                       value="" required autofocus>
                                            </div>
                                        </div>

                                        <!--Type-->
                                        <div class="row form-group{{ $errors->has('animal_type') ? ' has-error' : '' }} form-inline">
                                            <div class="col-md-3">
                                                <label for="animal_type" class="inline-label">Vrsta:</label>

                                                @if ($errors->has('animal_type'))
                                                    <span class="help-block">
                                            <strong>{{ $errors->first('animal_type') }}</strong>
                                        </span>
                                                @endif
                                            </div>
                                            <div class="col-md-6">
                                                <div class="col-md-6">
                                                    <select name="animal_type" id="animal_type" class="form-group form-control">
                                                        @for($i = 0; $i < count($type); $i++)
                                                            <option value="{{$type[$i]->id}}">{{$type[$i]->name}}</option>
                                                        @endfor
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <!--User-->
                                        <div class="row form-group{{ $errors->has('user_id') ? ' has-error' : '' }} form-inline">
                                            <div class="col-md-3">
                                                <label for="user_id" class="inline-label">Korisnik:</label>

                                                @if ($errors->has('user_id'))
                                                    <span class="help-block">
                                            <strong>{{ $errors->first('user_id') }}</strong>
                                        </span>
                                                @endif
                                            </div>
                                            <div class="col-md-6">
                                                <div class="col-md-6">
                                                    <select name="user_id" id="user_id" class="form-group form-control">
                                                        @for($i = 0; $i < count($user); $i++)
                                                            <option value="{{$user[$i]->id}}">{{$user[$i]->first_name}} {{$user[$i]->last_name}}</option>
                                                        @endfor
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-md-12 col-md-offset-4">
                                            <button type="submit" class="btn btn-primary btn-confirm">
                                                Kreiranje životinje
                                            </button>
                                        </div>
                                    </div>
                                </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js_after')

    @include('user.scripts')

@endsection
