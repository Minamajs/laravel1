@extends('layouts.app')

@section('content')

    <div class="block block-content block-content-full container-fluid">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">

                    <!-- Page Content -->
                    <div class="content">
                        <!-- Dynamic Table Full -->


                        <table class="table table-bordered table-hover" id="ourDatatable">
                            <thead>
                            <tr>
                                <th>Ime</th>
                                <th>Starost</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($animals as $animal)
                                <tr>
                                    <td>{{$animal->name}}</td>
                                    <td>{{$animal->age}}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                        <!-- END Dynamic Table Full -->
                        <div class="pb-3 text-right">
                            <button class=' btn btn-primary btn-md create-user' data-toggle='tooltip'
                                    data-placement='top' title='Novi korisnik'>
                                <a style="color: white" href="{{url('/animals/create')}}">Unos nove životinje</a>
                            </button>

                            <button class=' btn btn-primary btn-md create-user' data-toggle='tooltip'
                                    data-placement='top' title='Novi korisnik'>
                                <a style="color: white" href="{{url('/')}}">Kontrolna tabla</a>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js_after')

    @include('user.scripts')

@endsection
