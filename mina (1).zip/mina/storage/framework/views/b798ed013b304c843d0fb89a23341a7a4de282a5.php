<?php $__env->startSection('content'); ?>

    <div class="block block-content block-content-full container-fluid">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">

                    <!-- Page Content -->
                    <div class="content">

                        <form action="<?php echo e(route('animal.store')); ?>" method="POST"
                              class="form-horizontal form-bordered form-validate"
                              enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="row justify-content-center">

                                <div class="col-md-6">


                                    <div class="container">
                                        <!--Name-->
                                        <div class="row form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?> form-inline">
                                            <div class="col-md-3">
                                                <label for="name" class="inline-label">Ime:</label>

                                                <?php if($errors->has('name')): ?>
                                                    <span class="help-block">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-6">
                                                <input id="name" type="text" class="form-control" name="name"
                                                       value="">
                                            </div>
                                        </div>
                                        <!--Age-->
                                        <div class="row form-group<?php echo e($errors->has('age') ? ' has-error' : ''); ?> form-inline">
                                            <div class="col-md-3">
                                                <label for="age" class="inline-label">Starost:</label>

                                                <?php if($errors->has('age')): ?>
                                                    <span class="help-block">
                                            <strong><?php echo e($errors->first('age')); ?></strong>
                                        </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-6">
                                                <input id="age" type="number" class="form-control" name="age"
                                                       value="" required autofocus>
                                            </div>
                                        </div>

                                        <!--Type-->
                                        <div class="row form-group<?php echo e($errors->has('animal_type') ? ' has-error' : ''); ?> form-inline">
                                            <div class="col-md-3">
                                                <label for="animal_type" class="inline-label">Vrsta:</label>

                                                <?php if($errors->has('animal_type')): ?>
                                                    <span class="help-block">
                                            <strong><?php echo e($errors->first('animal_type')); ?></strong>
                                        </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="col-md-6">
                                                    <select name="animal_type" id="animal_type" class="form-group form-control">
                                                        <?php for($i = 0; $i < count($type); $i++): ?>
                                                            <option value="<?php echo e($type[$i]->id); ?>"><?php echo e($type[$i]->name); ?></option>
                                                        <?php endfor; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <!--User-->
                                        <div class="row form-group<?php echo e($errors->has('user_id') ? ' has-error' : ''); ?> form-inline">
                                            <div class="col-md-3">
                                                <label for="user_id" class="inline-label">Korisnik:</label>

                                                <?php if($errors->has('user_id')): ?>
                                                    <span class="help-block">
                                            <strong><?php echo e($errors->first('user_id')); ?></strong>
                                        </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="col-md-6">
                                                    <select name="user_id" id="user_id" class="form-group form-control">
                                                        <?php for($i = 0; $i < count($user); $i++): ?>
                                                            <option value="<?php echo e($user[$i]->id); ?>"><?php echo e($user[$i]->first_name); ?> <?php echo e($user[$i]->last_name); ?></option>
                                                        <?php endfor; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-md-12 col-md-offset-4">
                                            <button type="submit" class="btn btn-primary btn-confirm">
                                                Kreiranje životinje
                                            </button>
                                        </div>
                                    </div>
                                </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_after'); ?>

    <?php echo $__env->make('user.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>