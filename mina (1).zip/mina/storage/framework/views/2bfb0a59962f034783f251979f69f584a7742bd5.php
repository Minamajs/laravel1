<?php $__env->startSection('content'); ?>

    <div class="block block-content block-content-full container-fluid">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Kontrolna tabla</div>

                    <!-- Page Content -->
                    <div class="content">
                        <div class="pb-3 text-right">
                            <button class=' btn btn-primary btn-md create-user' data-toggle='tooltip'
                                    data-placement='top' title='Novi korisnik'>
                                <a style="color: white" href="<?php echo e(url('/users')); ?>">Korisnici</a>
                            </button>
                        </div>

                        <div class="pb-3 text-right">
                            <button class=' btn btn-primary btn-md create-user' data-toggle='tooltip'
                                    data-placement='top' title='Novi korisnik'>
                                <a style="color: white" href="<?php echo e(url('/animals')); ?>">Životinje</a>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_after'); ?>

    <?php echo $__env->make('user.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>