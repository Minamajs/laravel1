<?php $__env->startSection('content'); ?>

    <div class="block block-content block-content-full container-fluid">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Kontrolna tabla</div>

                    <!-- Page Content -->
                    <div class="content">
                        <!-- Dynamic Table Full -->


                        <table class="table table-bordered table-hover" id="ourDatatable">
                            <thead>
                            <tr>
                                <th>Ime</th>
                                <th>Prezime</th>
                                <th>Email</th>
                                <th>Akcije</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->first_name); ?></td>
                                    <td><?php echo e($user->last_name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td id="<?php echo e($user->id); ?>">
                                        <button class='btn btn-primary btn-sm user-edit' data-toggle='tooltip'
                                                data-placement='top' title='Izmena korisnika'>
                                            <i class='si si-pencil'></i>
                                        </button>
                                        <button class='btn btn-danger btn-sm user-delete' data-toggle='tooltip'
                                                data-placement='top' title='Brisanje korisnika'>
                                            <i class='si si-trash'></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <!-- END Dynamic Table Full -->
                        <div class="pb-3 text-right">
                            <button class=' btn btn-primary btn-md create-user' data-toggle='tooltip'
                                    data-placement='top' title='Novi korisnik'>
                                <a style="color: white" href="<?php echo e(url('/users/create')); ?>">Unos novog korisnika</a>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_after'); ?>

    <?php echo $__env->make('scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>