<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('register', 'Api\UserAuthController@register')->name('user.register');
Route::post('login', 'Api\UserAuthController@login')->name('user.login');
Route::post('logout', 'Api\UserAuthController@logout')->name('user.logout');
Route::patch('update', 'Api\UserController@update')->name('user.update');
Route::post('remove', 'Api\UserController@remove')->name('user.remove');

Route::get('my-animals', 'Api\UserController@myAnimals')->name('user.animals');
