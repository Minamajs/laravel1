<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('login', 'AdminController@showLoginForm')->name('login');
Route::post('login', 'AdminController@login')->name('login.submit');
Route::post('logout', 'AdminController@logout')->name('logout');


Route::group(['middleware' => ['auth']], function () {
    Route::get('/', 'HomeController@index')->name('dashboard');

});

Route::prefix('/users')->group(function () {
    Route::group(['middleware' => ['auth']], function () {
        Route::get('/', 'UserController@users')->name('users');
        Route::get('create', 'UserController@create')->name('user.create');
        Route::post('store', 'UserController@store')->name('user.store');
    });
});

Route::prefix('/animals')->group(function () {
    Route::group(['middleware' => ['auth']], function () {
        Route::get('/', 'AnimalController@animals')->name('animals');
        Route::get('create', 'AnimalController@create')->name('animal.create');
        Route::post('store', 'AnimalController@store')->name('animal.store');
    });
});




